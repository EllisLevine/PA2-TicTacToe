
public enum ButtonType {
	WINTER, SUMMER
}


