
public interface Button {

	ButtonType getButtonType();
	
}
