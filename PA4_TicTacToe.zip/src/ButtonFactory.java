
public interface ButtonFactory {
	
	Button createButton();

}
